# TE v6.0 Stage 10.2 Production Retry Comparison

Schema: `6.0.0-stage10.2`

| Metric | Baseline | Current | Delta |
|---|---:|---:|---:|
| Chunks observed | 5 | 5 | +0 |
| QA attempts | 6 | 5 | -1 |
| Provider retry decisions | 1 | 0 | -1 |
| Targeted retry | 0 | 0 | +0 |
| Full retry | 0 | 2 | +2 |
| Local repair | 0 | 1 | +1 |
| Recovery budget used | 0 | 0 | +0 |
| Retry rate | 20.00% | 0.00% | -20.00% |
| Accepted rate | 80.00% | 100.00% | +20.00% |

## Interpretation

- Current stage required fewer final Provider-retry decisions than baseline.
- Current stage resolved 1 chunk(s) through deterministic local repair.
- Current stage selected full retry for 2 chunk(s).
- Baseline and current metrics use different report generations; compare retry-tier fields cautiously.

## Warnings

- Baseline: Legacy baseline lacks Stage 10 retry-tier and recovery-budget metadata.
